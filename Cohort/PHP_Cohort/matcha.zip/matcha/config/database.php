<?php
    $DB_NAME = "matcha";
    $DB_DSN_NAME = "mysql:host=localhost;dbname=".$DB_NAME;
    $DB_DSN = "mysql:host=localhost";
    $DB_USER = "root";
    $DB_PASSWORD = "123456";
?>